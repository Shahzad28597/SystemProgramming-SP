int isequal(int var1,int var2);
void swap(int *v1, int *v2);
