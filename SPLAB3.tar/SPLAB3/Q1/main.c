#include<stdio.h>
#include<stdlib.h>
#include "MyMath.h"
void main()
{
	int var1=0;
	int var2=0;
	printf("This is a main function..!\n");
	printf("Enter First Number..!\n");
	scanf("%d",&var1);
	printf("Enter second Number..!\n");
	scanf("%d",&var2);
	printf("Now i will check the two variabls to b equal or not..!\n");
	if (isequal(var1,var2)==1)
	{
		printf("Both Variables are equal..!\n");
	}
	else printf("Both Variables are not equal..!\n");
	printf("Now i will swap the two variabls and print their values..!\n");
	swap(&var1,&var2);
	printf("Values after swaping are as follows\n");
	printf("var1 contains: %d",var1);
	printf("\nvar2 contains: %d",var2);

	
}
