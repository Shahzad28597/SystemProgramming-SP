int isequal(int var1,int var2)
{
	if(var1==var2)
	{
		return 1;
	}
	else return -1;
}

void swap(int *v1, int *v2)
{
	int temp=*v1;
	*v1=*v2;
	*v2=temp;
}
