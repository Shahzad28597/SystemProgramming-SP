
int isPalindrome(char *array,int size)
{
	int midsize = 0;
	for (int i = 0,j = size-1;1 <= size/2 ; i++,j--)
	{
		if (array[i] != array [j])
		{
			break;
			return -1;
		}
	}
	return 1;
}
