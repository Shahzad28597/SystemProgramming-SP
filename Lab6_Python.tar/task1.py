num = []
for i in range(2000,3200):
	if i % 5 == 0:
		pass
	else:
		if i % 7 == 0:
			num.append(i)
print num
 
